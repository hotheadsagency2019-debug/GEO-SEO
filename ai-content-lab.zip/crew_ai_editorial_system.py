"""
Author: https://github.com/tiagomonteiro0715
Date: 2025-08-03
Linkedin: https://www.linkedin.com/in/tiago-monteiro-/

Multi-agent system using the crewAI framework to create GEO/AEO and SEO articles
for the HotHeads Band agency blog (hot-head.ru), published via Tilda Zero Block.

Agents:
- Senior Research Analyst
- Audience Intelligence Specialist
- Lead Content Writer (GEO/AEO format)
- Senior Editorial Director (HHB quality checklist)
- GEO & SEO Optimization Specialist
"""

import warnings
warnings.filterwarnings("ignore")
from crewai import Agent, Task, Crew, LLM
import os
import json
import re
from datetime import datetime


"""
Anthropic (Claude) API Key
"""

llm = LLM(
    model="anthropic/claude-sonnet-4-6",
    api_key="API-KEY-HERE",
)


"""
HotHeads Band — фирменный CSS для Tilda Zero Block.
Агент-райтер вставляет эти стили дословно в <style> каждой статьи.
"""
HHB_CSS = """
  /* ── Zero Block height fix ── */
  .t-zeroblock, .t-zeroblock__container,
  .t-zeroblock__grid, .t-zeroblock__window,
  .t-zeroblock > div, .t-zeroblock__content {
    height: auto !important;
    min-height: 0 !important;
    max-height: none !important;
    overflow: visible !important;
    position: relative !important;
    max-width: 100% !important;
    width: 100% !important;
  }
  /* ── Break out of Tilda fixed container ── */
  .hu-article {
    width: 100vw !important;
    max-width: 100vw !important;
    position: relative !important;
    left: 50% !important;
    right: 50% !important;
    margin-left: -50vw !important;
    margin-right: -50vw !important;
    overflow-x: hidden;
  }
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  .hu-article {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 17px;
    line-height: 1.75;
    color: #1a1a2e;
    background: #fff;
  }
  .hu-article .container {
    max-width: 820px;
    width: 100%;
    margin: 0 auto;
    padding: 40px 24px 80px;
    overflow-x: hidden;
  }
  /* ── Global overflow fix ── */
  .hu-article * { max-width: 100%; }
  .hu-article img { max-width: 100%; height: auto; }
  .hu-article .table-wrap {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
    margin: 28px 0;
    width: 100%;
  }
  .hu-article table { min-width: 480px; }
  /* ── Header ── */
  .hu-article .article-header {
    margin-bottom: 40px;
    padding-bottom: 32px;
    border-bottom: 2px solid #f0f0f5;
  }
  .hu-article .article-tag {
    display: inline-block;
    background: #e9e9e9;
    color: #3e3e3e;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: .04em;
    text-transform: uppercase;
    padding: 4px 12px;
    border-radius: 20px;
    margin-bottom: 18px;
  }
  .hu-article h1 {
    font-size: clamp(26px, 4vw, 38px);
    font-weight: 900;
    line-height: 1.2;
    color: #0d0d1a;
    margin-bottom: 20px;
  }
  .hu-article .article-meta {
    font-size: 14px;
    color: #666;
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
  }
  .hu-article .article-meta span { display: flex; align-items: center; gap: 5px; }
  .hu-article .article-meta a { color: #3e3e3e; text-decoration: none; font-weight: 700; }
  /* ── Lead ── */
  .hu-article .lead {
    font-size: 19px;
    line-height: 1.65;
    color: #333;
    margin-bottom: 40px;
    padding: 24px 28px;
    background: #e9e9e9;
    border-left: 4px solid #3e3e3e;
    border-radius: 0 8px 8px 0;
  }
  /* ── TOC ── */
  .hu-article .toc {
    background: #e9e9e9;
    border: 1px solid #c8cdd9;
    border-radius: 10px;
    padding: 24px 28px;
    margin-bottom: 48px;
  }
  .hu-article .toc h2 {
    font-size: 13px;
    font-weight: 800;
    color: #3e3e3e;
    text-transform: uppercase;
    letter-spacing: .06em;
    margin-bottom: 12px;
    border: none;
    padding: 0;
  }
  .hu-article .toc ol { padding-left: 20px; display: grid; gap: 6px; }
  .hu-article .toc a { color: #3e3e3e; text-decoration: none; font-size: 15px; }
  .hu-article .toc a:hover { text-decoration: underline; }
  /* ── Headings ── */
  .hu-article h2 {
    font-size: clamp(21px, 3vw, 27px);
    font-weight: 800;
    color: #0d0d1a;
    margin: 52px 0 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #f0f0f5;
  }
  .hu-article h3 { font-size: 19px; font-weight: 700; color: #1a1a2e; margin: 32px 0 12px; }
  .hu-article h4 {
    font-size: 13px; font-weight: 800; color: #3e3e3e;
    margin: 24px 0 8px; text-transform: uppercase; letter-spacing: .05em;
  }
  /* ── Body text ── */
  .hu-article p { margin-bottom: 18px; }
  .hu-article p:last-child { margin-bottom: 0; }
  .hu-article strong { font-weight: 700; }
  .hu-article a { color: #3e3e3e; }
  /* ── Stats grid ── */
  .hu-article .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px; margin: 28px 0;
  }
  .hu-article .stat-card {
    background: #e9e9e9; border: 1px solid #c8cdd9;
    border-radius: 10px; padding: 20px; text-align: center;
  }
  .hu-article .stat-number { font-size: 30px; font-weight: 900; color: #3e3e3e; line-height: 1.1; display: block; }
  .hu-article .stat-label { font-size: 13px; color: #555; margin-top: 6px; line-height: 1.35; }
  /* ── Network cards ── */
  .hu-article .network-grid { display: grid; gap: 20px; margin: 28px 0; }
  .hu-article .network-card {
    border: 1px solid #e8e8f0; border-radius: 12px;
    padding: 24px; position: relative; transition: box-shadow .2s;
  }
  .hu-article .network-card:hover { box-shadow: 0 4px 20px rgba(120,132,164,.15); }
  .hu-article .network-card .badge {
    position: absolute; top: 20px; right: 20px;
    font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 20px;
  }
  .hu-article .badge-top { background: #e9e9e9; color: #3e3e3e; }
  .hu-article .badge-grow { background: #fdf0e8; color: #e27829; }
  .hu-article .badge-niche { background: #f3f3f3; color: #555; }
  .hu-article .network-name { font-size: 18px; font-weight: 800; color: #0d0d1a; margin-bottom: 6px; }
  .hu-article .network-reach { font-size: 13px; color: #888; margin-bottom: 12px; font-weight: 600; }
  .hu-article .network-card p { font-size: 15px; margin-bottom: 10px; }
  .hu-article .network-card p:last-child { margin-bottom: 0; }
  .hu-article .pros-list { list-style: none; padding: 0; margin: 10px 0 0; display: flex; flex-wrap: wrap; gap: 8px; }
  .hu-article .pros-list li {
    background: #e9e9e9; color: #3e3e3e;
    font-size: 13px; font-weight: 600; padding: 4px 12px; border-radius: 20px;
  }
  /* ── Tables ── */
  .hu-article th {
    background: #3C3C3C; color: #fff;
    font-weight: 700; padding: 12px 16px; text-align: left; white-space: nowrap;
  }
  .hu-article td { padding: 11px 16px; border-bottom: 1px solid #f0f0f5; vertical-align: top; }
  .hu-article tr:nth-child(even) td { background: #f7f8fa; }
  .hu-article tr:last-child td { border-bottom: none; }
  /* ── Callouts ── */
  .hu-article .callout { border-radius: 10px; padding: 20px 24px; margin: 28px 0; font-size: 15px; line-height: 1.65; }
  .hu-article .callout-tip  { background: #e9e9e9; border-left: 4px solid #3e3e3e; }
  .hu-article .callout-warn { background: #fdf6e8; border-left: 4px solid #e8a020; }
  .hu-article .callout-info { background: #fdf0e8; border-left: 4px solid #e27829; }
  .hu-article .callout strong { display: block; margin-bottom: 6px; color: #0d0d1a; }
  /* ── Step list ── */
  .hu-article .step-list { list-style: none; padding: 0; margin: 20px 0; counter-reset: steps; }
  .hu-article .step-list li {
    counter-increment: steps; padding: 14px 16px 14px 60px;
    position: relative; border-bottom: 1px solid #f0f0f5; font-size: 15px;
  }
  .hu-article .step-list li:last-child { border-bottom: none; }
  .hu-article .step-list li::before {
    content: counter(steps); position: absolute; left: 14px; top: 18px;
    width: 30px; height: 30px; background: #3e3e3e; color: #fff;
    font-weight: 800; font-size: 14px; border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
  }
  /* ── Expert quote ── */
  .hu-article .expert-quote {
    margin: 36px 0; padding: 28px 32px;
    background: #fdf0e8; border-left: 4px solid #e27829;
    border-radius: 0 12px 12px 0; position: relative;
  }
  .hu-article .expert-quote::before {
    content: "\\201C"; font-size: 72px; line-height: 1; color: #c9b8e8;
    position: absolute; top: 12px; left: 18px; font-family: Georgia, serif;
  }
  .hu-article .expert-quote blockquote {
    font-size: 17px; line-height: 1.7; color: #1a1a2e;
    font-style: italic; margin: 0 0 14px 28px;
  }
  .hu-article .expert-quote cite { font-style: normal; font-size: 14px; color: #555; margin-left: 28px; display: block; }
  .hu-article .expert-quote cite strong { color: #3e3e3e; }
  /* ── FAQ ── */
  .hu-article .faq-item { border-bottom: 1px solid #f0f0f5; padding: 20px 0; }
  .hu-article .faq-item:last-child { border-bottom: none; }
  .hu-article .faq-q { font-size: 17px; font-weight: 700; color: #0d0d1a; margin-bottom: 10px; }
  .hu-article .faq-a { font-size: 15px; color: #444; }
  /* ── Forecast ── */
  .hu-article .forecast-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin: 24px 0; }
  .hu-article .forecast-card { background: #fff; border: 1px solid #e8e8f0; border-radius: 10px; padding: 20px; }
  .hu-article .forecast-card h4 {
    font-size: 13px; color: #3e3e3e; font-weight: 800;
    text-transform: uppercase; letter-spacing: .05em; margin: 0 0 8px; border: none; padding: 0;
  }
  .hu-article .forecast-card p { font-size: 14px; color: #444; margin: 0; }
  /* ── Cases ── */
  .hu-article .cases-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin: 28px 0; }
  .hu-article .case-card {
    border: 1px solid #e8e8f0; border-radius: 14px;
    padding: 24px; background: #fff; transition: box-shadow .2s, transform .15s;
  }
  .hu-article .case-card:hover { box-shadow: 0 6px 28px rgba(120,132,164,.2); transform: translateY(-2px); }
  .hu-article .case-card-nda { background: #fafafa; border-style: dashed; }
  .hu-article .case-header {
    display: flex; justify-content: space-between;
    align-items: flex-start; gap: 12px; margin-bottom: 10px; flex-wrap: wrap;
  }
  .hu-article .case-name { display: block; font-size: 18px; font-weight: 800; color: #0d0d1a; line-height: 1.2; }
  .hu-article .case-category { display: block; font-size: 13px; color: #888; margin-top: 3px; }
  .hu-article .case-tags { display: flex; flex-wrap: wrap; gap: 6px; justify-content: flex-end; }
  .hu-article .case-tag { font-size: 11px; font-weight: 700; padding: 3px 9px; border-radius: 20px; background: #e9e9e9; color: #3e3e3e; white-space: nowrap; }
  .hu-article .tag-geo { background: #fdf0e8; color: #e27829; }
  .hu-article .case-duration { font-size: 12px; color: #aaa; font-weight: 600; letter-spacing: .03em; text-transform: uppercase; margin-bottom: 16px; }
  .hu-article .case-results { display: flex; gap: 16px; margin-bottom: 16px; padding: 16px; background: #e9e9e9; border-radius: 10px; }
  .hu-article .case-result { flex: 1; text-align: center; }
  .hu-article .result-number { display: block; font-size: 24px; font-weight: 900; color: #3e3e3e; line-height: 1.1; }
  .hu-article .result-label { display: block; font-size: 11px; color: #666; margin-top: 4px; line-height: 1.3; }
  .hu-article .case-logo { width: 52px; height: 52px; border-radius: 12px; object-fit: cover; flex-shrink: 0; border: 1px solid #e8e8f0; }
  .hu-article .case-app-info { display: flex; align-items: center; gap: 12px; }
  .hu-article a.case-card-link {
    display: block; text-decoration: none; color: inherit;
    border: 1px solid #e8e8f0; border-radius: 14px;
    padding: 24px; background: #fff; transition: box-shadow .2s, transform .15s;
  }
  .hu-article a.case-card-link:hover { box-shadow: 0 6px 28px rgba(120,132,164,.2); transform: translateY(-2px); }
  .hu-article a.case-card-link.case-card-nda { background: #fafafa; border-style: dashed; }
  /* ── CTA ── */
  .hu-article .cta-block {
    margin: 48px 0 0;
    background: linear-gradient(135deg, #3C3C3C 0%, #4a4a4a 60%, #3C3C3C 100%);
    border-radius: 16px; padding: 36px 40px;
    display: flex; align-items: center; gap: 32px; flex-wrap: wrap;
    position: relative; overflow: hidden;
  }
  .hu-article .cta-block::before {
    content: ""; position: absolute; top: 0; right: 0;
    width: 300px; height: 100%;
    background: linear-gradient(135deg, transparent, rgba(120,132,164,.25));
    pointer-events: none;
  }
  .hu-article .cta-text { flex: 1; min-width: 200px; position: relative; }
  .hu-article .cta-title { font-size: 20px; font-weight: 800; color: #fff; margin-bottom: 8px; }
  .hu-article .cta-body { font-size: 15px; color: rgba(255,255,255,.8); line-height: 1.6; margin: 0; }
  .hu-article .cta-btn {
    display: inline-block; background: transparent; color: #fff;
    border: 2px solid #fff; font-weight: 800; font-size: 15px;
    padding: 12px 28px; border-radius: 10px; text-decoration: none; white-space: nowrap;
    transition: background .15s, transform .15s; position: relative;
  }
  .hu-article .cta-btn:hover { background: rgba(255,255,255,.15); transform: translateY(-1px); }
  /* ── Footer ── */
  .hu-article .article-footer { margin-top: 60px; padding-top: 32px; border-top: 2px solid #f0f0f5; font-size: 13px; color: #888; }
  /* ══════════════════════════════
     TABLET: 768px
  ══════════════════════════════ */
  @media (max-width: 768px) {
    .hu-article .container { padding: 28px 20px 60px; }
    .hu-article h1 { font-size: 28px; }
    .hu-article h2 { font-size: 22px; margin: 40px 0 16px; }
    .hu-article h3 { font-size: 17px; }
    .hu-article .lead { font-size: 17px; padding: 18px 20px; }
    .hu-article .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
    .hu-article .forecast-grid { grid-template-columns: repeat(2, 1fr); }
    .hu-article .cases-grid { grid-template-columns: 1fr; }
    .hu-article .network-card { padding: 18px; }
    .hu-article .toc { padding: 18px 20px; }
    .hu-article .callout { padding: 16px 18px; }
    .hu-article .cta-block { padding: 28px 24px; gap: 24px; }
    .hu-article .expert-quote { padding: 20px 20px 20px 24px; }
    .hu-article .expert-quote::before { font-size: 52px; top: 8px; left: 12px; }
    .hu-article .expert-quote blockquote { margin-left: 16px; font-size: 15px; }
    .hu-article .expert-quote cite { margin-left: 16px; }
  }
  /* ══════════════════════════════
     MOBILE: 480px
  ══════════════════════════════ */
  @media (max-width: 480px) {
    .hu-article .container { padding: 20px 16px 48px; }
    .hu-article h1 { font-size: 24px; line-height: 1.25; }
    .hu-article .article-meta { flex-direction: column; gap: 6px; font-size: 13px; }
    .hu-article .article-tag { font-size: 11px; padding: 3px 10px; }
    .hu-article .lead { font-size: 16px; padding: 16px; border-left-width: 3px; }
    .hu-article .toc { padding: 16px; }
    .hu-article .toc ol { padding-left: 16px; }
    .hu-article .toc a { font-size: 14px; }
    .hu-article h2 { font-size: 20px; margin: 32px 0 14px; }
    .hu-article h3 { font-size: 16px; margin: 24px 0 10px; }
    .hu-article p { font-size: 16px; }
    .hu-article .stats-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
    .hu-article .stat-card { padding: 14px 10px; }
    .hu-article .stat-number { font-size: 22px; }
    .hu-article .stat-label { font-size: 12px; }
    .hu-article .table-wrap { margin: 16px -16px; border-radius: 0; }
    .hu-article table { font-size: 13px; min-width: 480px; }
    .hu-article th, .hu-article td { padding: 9px 12px; }
    .hu-article .forecast-grid { grid-template-columns: 1fr; gap: 10px; }
    .hu-article .forecast-card { padding: 14px; }
    .hu-article .network-card { padding: 16px; }
    .hu-article .network-card .badge { position: static; display: inline-block; margin-bottom: 10px; }
    .hu-article .network-name { font-size: 16px; padding-right: 0; }
    .hu-article .network-card p { font-size: 14px; }
    .hu-article .pros-list li { font-size: 12px; padding: 3px 10px; }
    .hu-article .expert-quote { padding: 16px; border-left-width: 3px; }
    .hu-article .expert-quote::before { display: none; }
    .hu-article .expert-quote blockquote { margin-left: 0; font-size: 15px; }
    .hu-article .expert-quote cite { margin-left: 0; }
    .hu-article .callout { padding: 14px 16px; font-size: 14px; border-left-width: 3px; }
    .hu-article .step-list li { padding: 12px 12px 12px 50px; font-size: 14px; }
    .hu-article .step-list li::before { left: 10px; top: 14px; width: 26px; height: 26px; font-size: 13px; }
    .hu-article .faq-q { font-size: 15px; }
    .hu-article .faq-a { font-size: 14px; }
    .hu-article .cases-grid { grid-template-columns: 1fr; gap: 14px; }
    .hu-article a.case-card-link { padding: 16px; }
    .hu-article .case-header { flex-direction: column; align-items: flex-start; gap: 10px; }
    .hu-article .case-tags { justify-content: flex-start; }
    .hu-article .case-logo { width: 44px; height: 44px; }
    .hu-article .case-name { font-size: 16px; }
    .hu-article .result-number { font-size: 20px; }
    .hu-article .case-results { padding: 12px; gap: 10px; }
    .hu-article .case-desc { font-size: 13px; }
    .hu-article .cta-block { flex-direction: column; align-items: flex-start; padding: 20px; gap: 16px; }
    .hu-article .cta-title { font-size: 18px; }
    .hu-article .cta-body { font-size: 14px; }
    .hu-article .cta-btn { width: 100%; text-align: center; padding: 14px; }
    .hu-article .article-footer { font-size: 12px; }
  }
  /* ══════════════════════════════
     VERY SMALL: 360px
  ══════════════════════════════ */
  @media (max-width: 360px) {
    .hu-article .stats-grid { grid-template-columns: 1fr 1fr; }
    .hu-article .stat-number { font-size: 20px; }
    .hu-article h1 { font-size: 22px; }
  }
"""


"""
Карта внутренних ссылок hot-head.ru (статические страницы).
Динамические статьи блога хранятся в hhb_sitemap.json и добавляются
автоматически после каждой генерации.
"""
STATIC_SITEMAP = [
    # ── Услуги: привлечение клиентов ──────────────────────────────────────
    {"title": "Яндекс Директ (контекстная реклама)",
     "url": "https://hot-head.ru/kontekstnaya-reklama",
     "when": "При упоминании контекстной рекламы, Яндекс Директ, поисковой рекламы"},
    {"title": "Реклама в Telegram (Telegram Ads)",
     "url": "https://hot-head.ru/telegram",
     "when": "При упоминании Telegram Ads, рекламы в Telegram, продвижения в Telegram"},
    {"title": "Реклама ВКонтакте (таргет)",
     "url": "https://hot-head.ru/target-reklama",
     "when": "При упоминании VK, ВКонтакте, таргетированной рекламы"},
    {"title": "Продвижение геоточки на Яндекс.Карты",
     "url": "https://hot-head.ru/reklama_yandex",
     "when": "При упоминании Яндекс.Карт, геотаргетинга, локального бизнеса"},
    {"title": "Внедрение AmoCRM",
     "url": "https://hot-head.ru/amocrm",
     "when": "При упоминании CRM, AmoCRM, воронки продаж, автоматизации"},
    {"title": "Продвижение строительных компаний",
     "url": "https://hot-head.ru/hhb_stroika",
     "when": "При упоминании рекламы для строительства, недвижимости, загородных домов"},
    {"title": "Продвижение театров и выставок",
     "url": "https://hot-head.ru/prodvizenie_teatrov_vistavok",
     "when": "При упоминании рекламы для мероприятий, театров, культурных событий"},
    # ── Услуги: анализ и аудиты ───────────────────────────────────────────
    {"title": "Комплексный аудит",
     "url": "https://hot-head.ru/audit",
     "when": "При упоминании аудита, проверки рекламы, диагностики"},
    {"title": "Анализ конкурентов",
     "url": "https://hot-head.ru/analiz_konkurentov",
     "when": "При упоминании конкурентного анализа, исследования рынка"},
    {"title": "Аудит рекламных кампаний",
     "url": "https://hot-head.ru/audit_reklami",
     "when": "При упоминании аудита рекламы, проверки эффективности кампаний"},
    # ── Контент и портфолио ───────────────────────────────────────────────
    {"title": "Кейсы агентства",
     "url": "https://hot-head.ru/keisi",
     "when": "При упоминании результатов, примеров работ, кейсов"},
    {"title": "Блог HotHeads Band",
     "url": "https://hot-head.ru/blog",
     "when": "При перекрёстных ссылках между статьями блога"},
    {"title": "Партнёрская программа",
     "url": "https://hot-head.ru/partner",
     "when": "При упоминании партнёрства, реферальных программ"},
    {"title": "Пригласить выступить (спикер)",
     "url": "https://hot-head.ru/spiker",
     "when": "При упоминании выступлений, конференций, экспертизы"},
    # ── Отдельные кейсы ───────────────────────────────────────────────────
    {"title": "Кейс: реклама театра",
     "url": "https://hot-head.ru/keis_reklamateatra",
     "when": "В статьях про рекламу мероприятий и театров"},
    {"title": "Кейс: строительные услуги",
     "url": "https://hot-head.ru/keis_stroitelnieuslugi",
     "when": "В статьях про рекламу в строительстве"},
    {"title": "Кейс: Telegram Ads для бизнес-игр",
     "url": "https://hot-head.ru/keis_bisnesigri",
     "when": "В статьях про Telegram Ads, продвижение онлайн-школ"},
    {"title": "Кейс: продвижение барнхаусов через Яндекс Директ",
     "url": "https://hot-head.ru/keisi_prodvijeniebarnhausov",
     "when": "В статьях про Яндекс Директ, строительные ниши"},
    # ── Контакты ──────────────────────────────────────────────────────────
    {"title": "Telegram агентства",
     "url": "https://t.me/hotheads_band",
     "when": "В CTA-блоках — основная точка контакта"},
    {"title": "Telegram-канал с кейсами",
     "url": "https://t.me/hotheads_band_digital",
     "when": "При упоминании Telegram-канала, кейсов в Telegram"},
    {"title": "Главная страница HotHeads Band",
     "url": "https://hot-head.ru/",
     "when": "При первом упоминании агентства в тексте"},
]

# Файл с динамической картой блога (пополняется после каждой статьи)
SITEMAP_FILE = "hhb_sitemap.json"


def load_dynamic_sitemap() -> list:
    """Загружает список ранее опубликованных статей блога из JSON-файла."""
    if not os.path.exists(SITEMAP_FILE):
        return []
    try:
        with open(SITEMAP_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def build_sitemap_text() -> str:
    """
    Собирает полную карту ссылок (статические + динамические статьи блога)
    в виде текста для передачи агенту-райтеру.
    """
    lines = [
        "=== КАРТА ВНУТРЕННИХ ССЫЛОК hot-head.ru ===",
        "Правила простановки ссылок:",
        "1. Вставляй ссылки только там, где они органично вписываются в контекст.",
        "2. На одну страницу — не более 1-2 ссылок в статье.",
        "3. Обязательно: в CTA-блоке ссылка на https://t.me/hotheads_band",
        "4. При первом упоминании конкретной услуги — давай ссылку на её страницу.",
        "5. Если есть раздел с кейсами — линкуй на релевантный кейс из списка.",
        "6. Статьи блога (раздел ниже) — линкуй при упоминании смежных тем.",
        "",
        "── Услуги и страницы сайта ──",
    ]
    for item in STATIC_SITEMAP:
        lines.append(f"  [{item['title']}]({item['url']}) — {item['when']}")

    dynamic = load_dynamic_sitemap()
    if dynamic:
        lines.append("")
        lines.append("── Статьи блога (опубликованные ранее) ──")
        for item in dynamic:
            lines.append(
                f"  [{item['title']}]({item['url']}) — {item.get('when', 'При упоминании смежной темы')}"
            )
    lines.append("=== КОНЕЦ КАРТЫ ССЫЛОК ===")
    return "\n".join(lines)


def _topic_to_slug(topic: str) -> str:
    """Генерирует URL-slug из темы статьи (латиница через транслит)."""
    translit = {
        "а":"a","б":"b","в":"v","г":"g","д":"d","е":"e","ё":"yo","ж":"zh","з":"z",
        "и":"i","й":"y","к":"k","л":"l","м":"m","н":"n","о":"o","п":"p","р":"r",
        "с":"s","т":"t","у":"u","ф":"f","х":"kh","ц":"ts","ч":"ch","ш":"sh",
        "щ":"shch","ъ":"","ы":"y","ь":"","э":"e","ю":"yu","я":"ya",
    }
    slug = topic.lower()
    slug = "".join(translit.get(c, c) for c in slug)
    slug = re.sub(r"[^a-z0-9]+", "-", slug).strip("-")
    return slug[:60]


def update_sitemap(topic: str, title: str) -> None:
    """
    Добавляет только что написанную статью в hhb_sitemap.json,
    чтобы будущие статьи могли на неё ссылаться.

    Args:
        topic: исходная тема, переданная в run_editorial_crew()
        title: H1-заголовок статьи (если известен), иначе тема
    """
    dynamic = load_dynamic_sitemap()
    slug = _topic_to_slug(topic)
    url = f"https://hot-head.ru/blog/{slug}"

    # Не дублировать, если уже есть запись с таким slug
    if any(item["url"] == url for item in dynamic):
        print(f" Sitemap: запись уже существует ({url}), пропускаю.")
        return

    dynamic.append({
        "title": title,
        "url": url,
        "when": f"При упоминании темы: {topic}",
        "added": datetime.now().strftime("%Y-%m-%d"),
    })

    with open(SITEMAP_FILE, "w", encoding="utf-8") as f:
        json.dump(dynamic, f, ensure_ascii=False, indent=2)

    print(f" Sitemap обновлён: добавлена статья «{title}» → {url}")
    print(f" Всего статей в базе: {len(dynamic)}")


"""
Agents
"""
research_and_fact_checker = Agent(
    role="Senior Research Analyst",
    goal=(
        "Conduct deep research and analysis on {topic} to identify trends, key insights, "
        "and supporting data specifically for the Russian digital advertising market. "
        "Focus on platforms available in Russia: VK (таргет), Яндекс Директ, Telegram Ads, "
        "Авито, Sber Ads, Urban Ads, Google Ads, and other foreign sources. "
        "NEVER mention Meta, Facebook, Instagram, Threads, or WhatsApp — these are banned in Russia."
    ),
    backstory=(
        "You are a seasoned research analyst with 15+ years of experience in the Russian digital "
        "advertising market. You specialise in identifying emerging patterns, key stakeholders, "
        "and data-driven insights across Russian platforms and niches. You have deep knowledge of "
        "VK Реклама, Яндекс Директ, Telegram Ads, MyTarget, Авито, and other platforms active "
        "in Russia. You always provide fact-checked, measurable, citation-ready insights — "
        "no vague statements, no marketing language. You never mention Meta or its products. "
        "All prices and examples are in Russian rubles and Russian market context."
    ),
    allow_delegation=True,
    verbose=True,
    max_iter=3,
    memory=True,
    llm=llm,
)

audience_analyst = Agent(
    role="Audience Intelligence Specialist",
    goal=(
        "Analyze the target audience for {topic} content for the HotHeads Band agency blog "
        "(hot-head.ru). HotHeads Band is a Russian performance advertising agency with 250+ projects "
        "across 50 niches, managing 520M+ rubles in ad budgets. "
        "Identify the reader profile: Russian digital marketers, SMB owners, and in-house media buyers "
        "at the research and decision-making stage. Recommend content approach for GEO/AEO format "
        "optimised for AI citation (ChatGPT, Perplexity, Google AI Overviews)."
    ),
    backstory=(
        "You are an audience intelligence expert focused on the Russian B2B digital marketing segment. "
        "You understand how Russian marketing professionals consume content, what pain points drive them "
        "to search for comparison and 'best of' articles, and what format makes content extractable "
        "by AI systems. You define personas, identify decision-stage intent, and recommend the "
        "structural and tonal approach that maximises both human engagement and AI citability."
    ),
    allow_delegation=False,
    verbose=True,
    max_iter=2,
    memory=True,
    llm=llm,
)

writer = Agent(
    role="Lead GEO/AEO Content Writer",
    goal=(
        "Write a complete GEO/AEO-optimised article on {topic} in HTML format for Tilda Zero Block, "
        "following the strict HotHeads Band (hot-head.ru) article structure and style. "
        "The article must follow this mandatory structure:\n"
        "1. SEO-optimised H1 title (contains year, 'Лучшие'/'Best', category name, max 70 chars)\n"
        "2. Intro paragraph (max 120 words, target audience, evaluation criteria, no marketing language)\n"
        "3. Quick Comparison Table (columns: Продукт | Лучше всего для | Цена от | Ключевое преимущество | Размер компании)\n"
        "4. 'Как мы оценивали' section (bulleted methodology: functionality depth, ease of use, pricing transparency, AI-readiness, integrations, market reputation, company stage fit)\n"
        "5. Numbered H2 sections per product (150-250 words each): Best For label, starting price, ideal company size, key advantages, limitations, unique differentiator, when to choose\n"
        "6. 'Ключевые отличия' section (3-5 neutral comparative theses, trade-offs)\n"
        "7. FAQ section (minimum 5 Q&A, 3-5 sentences per answer, direct and concise)\n"
        "8. Decision Matrix table (Если вы… | Выберите… | Почему)\n"
        "9. Neutral final conclusion\n"
        "10. CTA block linking to https://t.me/hotheads_band\n"
        "Minimum 2000 words, recommended 2500-4000 words.\n"
        "FORBIDDEN: images, long narrative paragraphs, vague statements, emotional language, "
        "superlatives ('революционный', 'game-changing'), first-person narration, storytelling, "
        "emojis, Meta/Facebook/Instagram/Threads/WhatsApp mentions."
    ),
    backstory=(
        "You are an expert GEO/AEO content writer specialising in comparison articles and 'best of' "
        "rankings optimised for AI citation (ChatGPT, Perplexity, Google AI Overviews). "
        "You write for the HotHeads Band agency blog (hot-head.ru) targeting Russian digital "
        "marketing professionals. Your output is always structured HTML using the HotHeads Band "
        "Zero Block component library: .hu-article container with 100vw breakout trick, "
        "article-header with article-tag/H1/article-meta (current month+year), lead paragraph, "
        "TOC nav, stats-grid, callout-warn (orange) and callout-tip (grey) only, expert-quote "
        "blocks (Алена Мумладзе), network-grid cards, cases-grid, cta-block, faq-item, table-wrap. "
        "Brand colours: #3e3e3e (dark accent), #e9e9e9 (light bg), #e27829 (orange), #3C3C3C (tables/CTA). "
        "Font: Inter. You never use purple or teal callout blocks. "
        "You always include the Zero Block height fix CSS at the top of the file. "
        "You never add <meta name='viewport'> — Tilda already has it."
    ),
    allow_delegation=False,
    verbose=True,
    max_iter=3,
    memory=True,
    llm=llm,
)


senior_editor = Agent(
    role="Senior Editorial Director — HotHeads Band",
    goal=(
        "Review the HTML article draft for {topic} against the mandatory HotHeads Band quality checklist. "
        "ALL 9 criteria must be satisfied before the article can be approved:\n"
        "1. All H2/H3 contain at least one search keyword related to the topic\n"
        "2. TOC (nav.toc) is synchronised with actual H2 headings in the article\n"
        "3. Callout blocks are ONLY orange (callout-warn) and grey (callout-tip) — no purple or teal\n"
        "4. Zero mentions of Meta, Facebook, Instagram, Threads, WhatsApp anywhere in the article\n"
        "5. FAQ section (min 5 questions), decision matrix table, and at least one comparison table are present\n"
        "6. At least one expert quote from Алена Мумладзе in the expert-quote component\n"
        "7. CTA block is present with a link to https://t.me/hotheads_band\n"
        "8. Responsive breakpoints 768px / 480px / 360px are implemented in CSS\n"
        "9. Date in article-meta shows current month and year (e.g. 'Март 2026') — not just a year\n"
        "Fix every failing criterion directly in the HTML. Return the corrected, complete HTML."
    ),
    backstory=(
        "You are the senior editorial director of HotHeads Band (hot-head.ru), with 20+ years in "
        "publishing and content quality assurance. You enforce the agency's strict brand standards: "
        "GEO/AEO structure, neutral analytical tone, no Meta product mentions (illegal in Russia), "
        "correct Tilda Zero Block HTML, responsive design, and mandatory content elements "
        "(expert quotes, FAQ, decision matrix, CTA). You do not approve any article that fails "
        "even one of the 9 checklist criteria. You also verify that the article tone is "
        "analytical and citation-ready — no marketing hype, no vague claims."
    ),
    allow_delegation=True,
    verbose=True,
    max_iter=3,
    memory=True,
    llm=llm,
)

seo_and_humanize_optimizer = Agent(
    role="GEO & SEO Optimization Specialist",
    goal=(
        "Apply final GEO/AEO and SEO optimisation to the article on {topic} so it ranks in search "
        "and gets cited by AI systems (ChatGPT, Perplexity, Google AI Overviews). Tasks:\n"
        "SEO:\n"
        "- Verify H1 contains: year, 'Лучшие'/'Best', category name, max 70 chars\n"
        "- Ensure all H2/H3 contain primary or secondary keywords — rewrite any that don't\n"
        "- Validate meta title (50-60 chars format: '[Тема] | HotHeads Band') and meta description (150-160 chars)\n"
        "- Confirm canonical URL format: https://hot-head.ru/blog/slug\n"
        "- Check keyword density: natural integration, no stuffing\n"
        "GEO/AEO (AI citation optimisation):\n"
        "- Ensure content is split into short semantic chunks (2-4 sentence paragraphs)\n"
        "- Confirm FAQ answers are 3-5 sentences, direct, no marketing language\n"
        "- Verify comparison tables have all required columns and short cell content\n"
        "- Confirm decision matrix rows are short and unambiguous\n"
        "- Ensure uniform terminology (no synonyms for the key category term)\n"
        "- Strip any remaining vague statements, superlatives, or narrative storytelling\n"
        "- Verify total article length is 2000-4000 words\n"
        "- Confirm zero mentions of Meta/Facebook/Instagram/Threads/WhatsApp"
    ),
    backstory=(
        "You are a GEO/AEO and SEO specialist who optimises content for both traditional search "
        "and AI-powered answer engines. You understand how ChatGPT, Perplexity, and Google AI Overviews "
        "extract and cite structured content. You apply semantic chunk optimisation, FAQ structuring, "
        "comparison table formatting, and decision matrix clarity to maximise AI citability. "
        "You simultaneously ensure traditional SEO requirements: keyword-rich headings, proper meta tags, "
        "canonical URLs, and keyword density. You are the final quality gate before publication — "
        "the article leaves your hands publication-ready for Tilda Zero Block with all Tilda-specific "
        "CSS fixes in place."
    ),
    allow_delegation=False,
    verbose=True,
    max_iter=2,
    memory=True,
    llm=llm,
)


"""
Tasks
"""

research_task = Task(
    description=(
        "Conduct comprehensive research on {topic} for the Russian digital advertising market:\n"
        "1. Identify the main tools/platforms/services in this category available in Russia\n"
        "2. Gather measurable data: pricing (in RUB where possible), key features, target company sizes\n"
        "3. Analyse the competitive landscape: who uses what and why\n"
        "4. Identify 3-7 specific products/tools to compare in the article\n"
        "5. Find credible facts, statistics, and differentiators for each product\n"
        "6. Note important trade-offs and limitations for each option\n"
        "IMPORTANT: Do NOT mention Meta, Facebook, Instagram, Threads, or WhatsApp. "
        "Russian alternatives: VK Реклама, Яндекс Директ, Telegram Ads, MyTarget, Авито."
    ),
    expected_output=(
        "A structured research report with: list of 3-7 products to compare, key data points "
        "(pricing in RUB, features, company fit) for each, competitive differentiators, "
        "trade-offs, and credible market statistics for {topic} in the Russian market."
    ),
    agent=research_and_fact_checker,
)

audience_task = Task(
    description=(
        "Analyse the target audience for a GEO/AEO comparison article on {topic} for hot-head.ru:\n"
        "1. Define the primary reader persona (Russian digital marketer / SMB owner / in-house media buyer)\n"
        "2. Identify decision-stage intent: what questions they are trying to answer\n"
        "3. Determine pain points that drive them to search for a 'best of' comparison\n"
        "4. Recommend content angle, tone (analytical/neutral), and which comparison criteria matter most\n"
        "5. Identify 5 FAQ questions this audience would ask about {topic}\n"
        "6. Suggest 'Decision Matrix' trigger scenarios: 'If you are [profile] → choose [tool]'"
    ),
    expected_output=(
        "Audience brief with: primary persona description, top 5 FAQ questions for this audience, "
        "recommended evaluation criteria order, decision matrix trigger scenarios, "
        "and tone/angle recommendation for the GEO article on {topic}."
    ),
    agent=audience_analyst,
)

writing_task = Task(
    description=(
        "Write the complete GEO/AEO article on {topic} in HTML for Tilda Zero Block.\n\n"
        "CRITICAL — CSS REQUIREMENT:\n"
        "Open the <style> tag and paste the following CSS VERBATIM — do not alter, shorten, "
        "or regenerate it. This is the official HotHeads Band stylesheet:\n\n"
        f"<style>\n{HHB_CSS}\n</style>\n\n"
        "HTML STRUCTURE (mandatory, in this order):\n"
        "1. <style> block with the verbatim CSS above\n"
        "2. <div class='hu-article'><div class='container'>\n"
        "3. article-header: article-tag span, H1 (year + 'Лучшие' + category ≤70 chars), "
        "article-meta with current month+year (Март 2026), reading time, HotHeads Band link\n"
        "4. <p class='lead'> — intro, max 120 words, target audience, evaluation criteria\n"
        "5. <nav class='toc'> — links to all H2 sections\n"
        "6. Quick Comparison Table in .table-wrap "
        "(columns: Продукт | Лучше всего для | Цена от | Ключевое преимущество | Размер компании)\n"
        "7. H2 'Как мы оценивали' — bulleted methodology\n"
        "8. Numbered H2 sections per product (150-250 words each): "
        "Best For, starting price, company size, key advantages, limitations, differentiator, when to choose\n"
        "9. H2 'Ключевые отличия' — 3-5 neutral comparative theses\n"
        "10. H2 'Часто задаваемые вопросы' — min 5 .faq-item blocks\n"
        "11. Decision Matrix in .table-wrap (Если вы… | Выберите… | Почему)\n"
        "12. Neutral conclusion paragraph\n"
        "13. .expert-quote block — quote from Алена Мумладзе, основательница HotHeads Band\n"
        "14. .cta-block — link to https://t.me/hotheads_band\n"
        "15. </div></div>\n\n"
        "INTERNAL LINKING (обязательно):\n"
        "Используй карту ссылок ниже для простановки внутренних ссылок в тексте статьи.\n"
        "{sitemap}\n\n"
        "RULES: min 2000 words. Only .callout-warn (orange) and .callout-tip (grey). "
        "No Meta/Facebook/Instagram/Threads/WhatsApp. No <meta name='viewport'>. "
        "No images. Short paragraphs (2-4 sentences). No marketing hype."
    ),
    expected_output=(
        "A complete, self-contained HTML snippet (no <html>/<head>/<body> tags) starting with "
        "<style> containing the verbatim HHB_CSS, followed by <div class='hu-article'> with all "
        "14 structural elements, with relevant internal links from the sitemap naturally embedded "
        "in the text. Ready to paste directly into Tilda Zero Block."
    ),
    agent=writer,
)

editing_task = Task(
    description=(
        "Review the HTML article on {topic} against the HotHeads Band 10-point quality checklist. "
        "Check each criterion and fix all failures directly in the HTML:\n"
        "☐ 1. The <style> block contains the complete verbatim HHB CSS — "
        "do NOT shorten, regenerate, or replace it; restore any missing rules\n"
        "☐ 2. All H2/H3 contain at least one search keyword — rewrite any that don't\n"
        "☐ 3. TOC (nav.toc) matches all H2 headings exactly — fix any mismatches\n"
        "☐ 4. Only orange (callout-warn) and grey (callout-tip) callout blocks — remove/replace others\n"
        "☐ 5. Zero mentions of Meta, Facebook, Instagram, Threads, WhatsApp — remove all occurrences\n"
        "☐ 6. FAQ (min 5 questions), decision matrix, and comparison table all present — add if missing\n"
        "☐ 7. Expert quote from Алена Мумладзе present in .expert-quote component — add if missing\n"
        "☐ 8. CTA block with https://t.me/hotheads_band link — add if missing\n"
        "☐ 9. article-meta date = current month + year (Март 2026) — fix if outdated or year-only\n"
        "☐ 10. No <meta name='viewport'> tag present — remove if found\n"
        "Do not return the article until all 10 criteria are satisfied."
    ),
    expected_output=(
        "The corrected, complete HTML snippet on {topic} with all 10 checklist criteria confirmed. "
        "Include a brief checklist report at the top as an HTML comment listing each criterion "
        "and its status (PASS/FIXED)."
    ),
    agent=senior_editor,
)

seo_and_humanize_task = Task(
    description=(
        "Apply final GEO/AEO + SEO pass to the HTML article on {topic}:\n"
        "SEO pass:\n"
        "- Verify/fix H1: year + 'Лучшие'/'Best' + category + max 70 chars\n"
        "- Check every H2/H3 contains a keyword — rewrite if needed\n"
        "- Add/fix HTML comment block with: meta title (50-60 chars), "
        "meta description (150-160 chars), canonical URL, 5-7 keywords\n"
        "- Verify natural keyword density, no stuffing\n"
        "GEO/AEO pass:\n"
        "- Enforce 2-4 sentence paragraph limit throughout\n"
        "- Check FAQ answers are 3-5 sentences, direct, no hype\n"
        "- Verify comparison table cells are short phrases, not paragraphs\n"
        "- Verify decision matrix rows are short and unambiguous\n"
        "- Enforce single consistent terminology for the category keyword\n"
        "- Remove any remaining vague statements, superlatives, or narrative storytelling\n"
        "- Confirm article is 2000-4000 words\n"
        "- Final check: zero Meta/Facebook/Instagram mentions\n"
        "Return the publication-ready HTML."
    ),
    expected_output=(
        "Publication-ready HTML for Tilda Zero Block: GEO/AEO-optimised, SEO-optimised, "
        "with SEO meta block comment, correct heading keywords, short semantic paragraphs, "
        "clean FAQ and decision matrix, 2000-4000 words, zero forbidden mentions. "
        "Ready to paste into Tilda Zero Block with height set to Авто."
    ),
    agent=seo_and_humanize_optimizer,
)


"""
Crew
"""

crew = Crew(
    agents=[
        research_and_fact_checker,
        audience_analyst,
        writer,
        senior_editor,
        seo_and_humanize_optimizer
    ],
    tasks=[
        research_task,
        audience_task,
        writing_task,
        editing_task,
        seo_and_humanize_task
    ],
    verbose=True
)

def run_editorial_crew(topic):
    """
    Run the editorial crew with the specified topic.

    Args:
        topic (str): The topic for the article generation

    Returns:
        str: The generated content
    """
    try:
        print(f" Starting HotHeads Band GEO/AEO Editorial Crew for topic: '{topic}'")
        dynamic = load_dynamic_sitemap()
        print(f" Sitemap loaded: {len(STATIC_SITEMAP)} static pages + {len(dynamic)} blog articles")
        print("=" * 60)

        result = crew.kickoff(inputs={
            "topic": topic,
            "sitemap": build_sitemap_text(),
        })

        print(" Content generation completed successfully!")
        return result

    except Exception as e:
        print(f" Error during content generation: {str(e)}")
        raise


def save_results(result, topic):
    """
    Save the generated results to an HTML file for Tilda Zero Block.

    Args:
        result: The generated content
        topic (str): The topic used for generation
    """
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"hhb_article_{timestamp}.html"

        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"<!-- HotHeads Band Article | Topic: {topic} | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} -->\n")
            f.write(f"<!-- Paste into Tilda Zero Block. Set Zero Block height to АВТО (not Фикс). -->\n\n")
            f.write(str(result))

        print(f" Results saved to: {filename}")
        print(f" Remember: in Tilda Zero Block set height to АВТО (not Фикс)!")
        return filename

    except Exception as e:
        print(f" Error saving results: {str(e)}")
        raise



if __name__ == "__main__":
    DEFAULT_TOPIC = "лучшие инструменты автоматизации рекламы в Яндекс Директ 2026"

    print(" HotHeads Band — GEO/AEO Editorial Crew")
    print("Создание SEO и GEO/AEO-статей для блога hot-head.ru")
    print("Agents: Research, Audience, GEO Writer, Editorial (HHB checklist), GEO+SEO Optimizer")
    print("=" * 60)

    try:
        result = run_editorial_crew(DEFAULT_TOPIC)
        filename = save_results(result, DEFAULT_TOPIC)

        # Добавляем статью в карту сайта для будущей перелинковки.
        # В качестве заголовка используем тему — можно заменить на
        # реальный H1, извлечённый из result, если нужна большая точность.
        update_sitemap(topic=DEFAULT_TOPIC, title=DEFAULT_TOPIC)

        print("\nProcess completed successfully!")
        print(f"Output file: {filename}")
        print("Next step: paste HTML into Tilda Zero Block, set height to АВТО.")

    except KeyboardInterrupt:
        print("\nProcess interrupted by user")
    except Exception as e:
        print(f"\nFatal error: {str(e)}")
        print("Please check your configuration and try again.")
